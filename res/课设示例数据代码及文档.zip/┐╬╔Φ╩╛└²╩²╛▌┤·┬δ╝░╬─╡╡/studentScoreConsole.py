# -*- coding: utf-8 -*-
"""
Created on Sun May 31 02:15:11 2020
# Successfull!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#########以这个为准！！！！！
@author: Aaron
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Apr 12 16:00:42 2020
@author: Jining Yan
运行环境：Windows系统，Python3.7
"""
import pandas as pd
import matplotlib.pyplot as plt
import os

#防止中文出现乱码
plt.rcParams['font.sans-serif']=['SimHei']#黑体
plt.rcParams['axes.unicode_minus'] = False



#【任务1】
def dataPreprocessing():
    while True:
        #读取数据
        fileName = input('请输入要打开的文件名studentScore.csv:')
        try:
            df = pd.read_csv(fileName, encoding='cp936')
            #丢弃缺失值
            df = df.dropna()
            df.to_csv('studentScoreP.csv', encoding='cp936',index=False)
            ##查看前三行
            print(df.head(3))
            ##查看后两行
            print(df.tail(2))
            print("任务1执行成功！")
            break 
        except:                          #打开文件失败时执行的代码
            print('文件不存在,请重新输入文件名')
    


#【任务2】
def dataSelection(): 
    while True:    
        #读取数据
        fileName = input('请输入要打开的文件名studentScoreP.csv:')
        try:
            df = pd.read_csv(fileName, encoding='cp936')
            df_new = df.loc[:,['姓名','考号','班级','语文','数学','英语']]
            try:
                df_new.to_csv('studentScoreP_new.csv', encoding='cp936',index=False)
                
                df_new = pd.read_csv('studentScoreP_new.csv', encoding='cp936')
                df_newGood = df_new[df_new['语文']>=100]
                df_newGood = df_newGood[df_new['语文']<=150]
                df_newGood = df_newGood[df_new['数学']>=100]
                df_newGood = df_newGood[df_new['数学']<=150]
                df_newGood = df_newGood[df_new['英语']>=100]
                df_newGood = df_newGood[df_new['英语']<=150]
                df_newGood.to_csv('studentScoreP_newGood.txt', encoding='cp936',index=False)
                print("任务2执行成功！")
                break
            except:#打开文件失败时执行的代码
                print('文件导出失败！')
        except:#打开文件失败时执行的代码
            print('文件不存在,请重新输入文件名')
#【任务3】
def dataGroup():
    while True:    
        #读取数据
        fileName = input('请输入要打开的文件名studentScoreP_new.csv:')
        try:
            df_new = pd.read_csv(fileName, encoding='cp936')
            df_new = df_new.loc[:,['班级','语文','数学','英语']]
            df_new_groupby = df_new.groupby(['班级'], as_index=False).mean()
            print(df_new_groupby)
            df_new_groupby.to_csv('studentScoreP_newGroup.txt', encoding='cp936',index=False)
            print("任务3执行成功！")
            break
        except:                          #打开文件失败时执行的代码
            print('文件不存在,请重新输入文件名')

#【任务4】
def dataCalculate():    
    while True:    
        #读取数据
        fileName = input('请输入要打开的文件名studentScoreP_new.csv:')
        try:
            df_new = pd.read_csv(fileName, encoding='cp936')
            df_new['均值'] = (df_new['语文'] + df_new['数学'] + df_new['英语'])/3.0
            df_new.sort_values(by='均值',ascending=False) #按列对数据进行降序排序
            df_new.to_excel('studentScoreP_Mean.xlsx', encoding='cp936',index=False)
            print("任务4执行成功！")
            break
        except:                          #打开文件失败时执行的代码
            print('文件不存在,请重新输入文件名')

#【任务5】
def dataDescribeVisualization():
    while True:    
        #读取数据
        fileName = input('请输入要打开的文件名studentScoreP_Mean.xlsx:')
        try:
            df_mean = pd.read_excel(fileName, encoding='cp936')
            df_mean_describe = df_mean.describe()
            print(type(df_mean_describe))#<class 'pandas.core.frame.DataFrame'>
            print(df_mean_describe)
            maxValue = df_mean_describe.at['max','均值']
            threeQuartersValue = df_mean_describe.at['75%','均值']
            medianValue = df_mean_describe.at['50%','均值']
            quarterValue = df_mean_describe.at['25%','均值']
            minValue = df_mean_describe.at['min','均值']
            category = [minValue, quarterValue, medianValue, threeQuartersValue,maxValue]
            labels = ['Poor', 'Moderate', 'Good', 'Excellent']
            mean_cut = pd.cut(df_mean['均值'],category, right=False, labels=labels)
            print(mean_cut)
            print(type(mean_cut))#<class 'pandas.core.series.Series'>
            mean_cut_counts = mean_cut.value_counts()
            print(mean_cut_counts)
            print(type(mean_cut_counts))#<class 'pandas.core.series.Series'>

            #柱状图
            plt.figure()
            mean_cut_counts.plot(kind='bar',figsize=(12,8))
            plt.xticks(rotation=0,fontsize=16)
            plt.yticks(fontsize=16)
            plt.title("平均成绩离散化统计柱状图")
            plt.savefig('studentScoreP_Mean_bar.png',dpi=400)
            plt.show()

            #饼状图
            plt.figure()
            mean_cut_counts.plot(kind='pie',figsize=(12,8))
            plt.title("平均成绩离散化统计饼状图")
            plt.savefig('studentScoreP_Mean_pie.png',dpi=400)
            plt.show()
            print("任务5执行成功！")
            break
        except:                          #打开文件失败时执行的代码
            print('文件不存在,请重新输入文件名')



#【任务6】
def dataVisualization():
     while True:    
        #读取数据
        fileName = input('请输入要打开的文件名studentScoreP_Mean.xlsx:')
        try:    
            df_mean = pd.read_excel(fileName, encoding='cp936')
            df_mean = df_mean.loc[:,['姓名','均值']]

            #利用matplotlib绘图
            plt.figure(figsize=(12,8))
            plt.plot(df_mean['姓名'],df_mean['均值'],label = '均值',color='red')
            plt.xlabel('姓名',fontsize=12)
            #姓名每隔5个抽样显示
            xlength = len(df_mean)
            print('xlength=',xlength)#65
            #构建xticks显示位置
            xticksloc = [i for i in range(xlength) if i%5==0]
            print('xticksloc=',xticksloc)#[0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60]
            #构建xticks显示标签
            xtickslabels = df_mean['姓名'].values[::5]
            print('xtickslabels',xtickslabels)
            plt.xticks(xticksloc,xtickslabels,rotation=30)#倾斜30度显示
            plt.ylabel('平均分',fontsize=12)
            plt.legend(fontsize=16)#显示图例并设置字号
            plt.title("学生平均成绩",fontsize=16)
            plt.savefig('studentScoreP_Mean.png',dpi=400)
            plt.show()
            print("任务6执行成功！")
            break
        except:                          #打开文件失败时执行的代码
            print('文件不存在,请重新输入文件名')



#系统主界面
def menu():
    print('【任务选择】\n'
          '＋－－－－学生成绩数据分析及可视化系统 －－－－－－－－－－＋\n'
          '｜0、退出。                                         ｜\n'
          '｜1、数据读取及预处理。                               ｜\n'
          '｜2、数据选择及导出。                                 ｜\n'
          '｜3、数据分类汇总。                                  ｜\n'
          '｜4、数据计算及排序。                                 ｜\n'
          '｜5、数据统计。                                      ｜\n'
          '｜6、数据可视化。                                    ｜\n'
          '＋－－－－－－－－－－－－－－－－－－－－－－－－－-－－－＋')
    
    

#功能选择模块
def task():
    while True:
        menu()#打印系统主界面
        num = input("请输入任务选项：")
        if num == '1':
            dataPreprocessing()
        elif num == '2':
            if os.path.exists('studentScoreP.csv'):
                dataSelection()
            else:
                print('未能执行当前选项，请先执行前面的选项！')
        elif num == '3':
            if os.path.exists('studentScoreP_new.csv'):
                dataGroup()
            else:
                print('未能执行当前选项，请先执行前面的选项！')
        elif num == '4':
            if os.path.exists('studentScoreP_new.csv'):
                dataCalculate()
            else:
                print('未能执行当前选项，请先执行前面的选项！')
        elif num == '5':
            if os.path.exists('studentScoreP_Mean.xlsx'):
                dataDescribeVisualization()
            else:
                print('未能执行当前选项，请先执行前面的选项！') 
        elif num == '6':
            if os.path.exists('studentScoreP_Mean.xlsx'):
                dataVisualization()
            else:
                print('未能执行当前选项，请先执行前面的选项！')
        elif num == '0':
            print('程序结束！')
            break
        else:
            print('输入选项有误')
        input("回车显示菜单")
#主函数
if __name__ == '__main__':        
    task()#调用功能选择函数